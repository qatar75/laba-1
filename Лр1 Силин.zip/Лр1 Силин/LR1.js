// Задача 1
// const books = [
//   { title: 'JS', level: 'base', pages: 240 },
//   { title: 'React', level: 'middle', pages: 310 },
//   { title: 'HTML', level: 'base', pages: 120 },
//   { title: 'CSS', level: 'base', pages: 280 },
// ]

// function getBaseBooks(items, minPages) {
//   return items
//     .filter(item => item.level === 'base' && item.pages >= minPages)
//     .map(item => `${item.title} — ${item.pages} стр.`)
// }

// console.log(getBaseBooks(books, 200))

// Задача 2
// const tasks = [
//   { id: 1, title: 'Макет', done: true },
//   { id: 2, title: 'Компонент', done: false },
//   { id: 3, title: 'README', done: true },
// ]

// function getTaskInfo(items, id) {
//   const task = items.find(item => item.id === id)
//   if (!task) return 'Задача не найдена'

//   const status = task.done ? 'выполнена' : 'в работе'
//   return `${task.title}: ${status}`
// }

// console.log(getTaskInfo(tasks, 2)) 
// console.log(getTaskInfo(tasks, 99)) 

// Задача 3
const orders = [
  { status: 'paid', total: 1200 },
  { status: 'new', total: 500 },
  { status: 'paid', total: 800 },
  { status: 'cancelled', total: 300 },
]

function getPaidSummary(items) {
  const paidOrders = items.filter(item => item.status === 'paid')
  const total = paidOrders.reduce((sum, item) => sum + item.total, 0)
  const count = paidOrders.length

  if (count === 0) return { count: 0, total: 0, average: 0 }
  const average = total / count
  return { count, total, average }
}

console.log(getPaidSummary(orders))